from flask import Flask, redirect, render_template, request, session, url_for
import os, subprocess
from datetime import date
from functools import wraps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TMPL_DIR = os.path.join(BASE_DIR, "Frontend", "templates")
STATIC_DIR = os.path.join(BASE_DIR, "Frontend", "static")
BACKEND_DIR = os.path.join(BASE_DIR, "Backend")
USERS_FILE = os.path.join(BACKEND_DIR, "data", "users.txt")
AUTH_EXE = os.path.join(BACKEND_DIR, "c_modules", "auth.exe")

app = Flask(__name__,
            template_folder = TMPL_DIR,
            static_folder=STATIC_DIR)
app.secret_key = os.environ.get("HEALTHDESK_SECRET", "healthdesk-dev-secret")

def is_authenticated():
    return session.get("logged_in", False)

def require_role(*allowed_roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if session.get("role") not in allowed_roles:
                return redirect("/")
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def read_users():
    users = []
    if not os.path.exists(USERS_FILE):
        return users

    try:
        with open(USERS_FILE, "r") as f:
            for line in f:
                data = line.strip().split("|")
                if len(data) >= 5:
                    users.append({
                        "user_id": data[0],
                        "username": data[1],
                        "password": data[2],
                        "role": data[3],
                        "doctor_id": data[4]
                    })
    except:
        pass

    return users

def generate_user_id():
    users = read_users()
    if not users:
        return 1

    return max(int(user["user_id"]) for user in users) + 1

def create_user(username, password, role, doctor_id):
    with open(USERS_FILE, "a") as f:
        f.write(f"{generate_user_id()}|{username}|{password}|{role}|{doctor_id}\n")

def authenticate_user(username, password):
    if not os.path.exists(AUTH_EXE):
        return None

    result = subprocess.run(
        [AUTH_EXE, username, password],
        cwd=BASE_DIR,
        capture_output=True,
        text=True
    )

    data = result.stdout.strip().split("|")
    if len(data) == 3 and data[0] == "OK":
        return {
            "username": username,
            "role": data[1],
            "doctor_id": data[2]
        }

    return None

@app.before_request
def require_login():
    public_endpoints = {"login", "signup", "static"}
    if request.endpoint in public_endpoints:
        return
    if not is_authenticated():
        return redirect(url_for("login"))

@app.context_processor
def inject_auth_state():
    return {
        "is_logged_in": is_authenticated(),
        "current_role": session.get("role", ""),
        "current_user": session.get("username", "")
    }


def read_queue():
    queue = []

    try:
        queue_file = os.path.join(BACKEND_DIR, "data", "queue.txt")
        with open(queue_file, "r") as f:
            for line in f:
                data = line.strip().split("|")

                queue.append({
                    "token": int(data[0]),
                    "patient_id": int(data[1]),
                    "doctor_id": int(data[2]),
                    "priority": data[3],
                    "status": data[4]
                })
    except:
        pass

    return queue

def process_queue(queue):

    queue.sort(key=lambda x: (x["priority"] != "Urgent", x["token"]))

    waiting = []
    completed = []

    for q in queue:
        if q["status"] == "Waiting":
            waiting.append(q)
        elif q["status"] == "Completed":
            completed.append(q)

    next_patient = waiting[0] if waiting else None

    return queue, next_patient, len(waiting), len(completed)

def count_patients():
    with open("Backend/data/patients.txt", "r") as f:
        return len(f.readlines())
    
def count_available_doctors():
    count = 0
    try:
        with open("Backend/data/doctors.txt", "r") as f:
            for line in f:
                data =line.strip().split("|")
                if data[4] == "Available" and data[5] == "Free":
                    count += 1
    except:
        pass
    return count


def get_doctors():
    doctors = []
    try:
        with open("Backend/data/doctors.txt", "r") as f:
            for line in f:
                data = line.strip().split("|")
                doctors.append({
                    "id": int(data[0]),
                    "name": data[1],
                    "department": data[2],
                    "experience": int(data[3]),
                    "daily_status": data[4],
                    "current_status": data[5]
                })
    except:
        pass
    return doctors

def suggest_doctors_by_department(department):
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")
    result = subprocess.run(
        [exe_path, "suggest", department],
        capture_output=True,
        text=True
    )

    doctors = []
    for line in result.stdout.strip().split("\n"):
        if not line or line == "NoDoctorFound":
            continue

        data = line.strip().split("|")
        if len(data) < 6:
            continue

        doctors.append({
            "id": int(data[0]),
            "name": data[1],
            "department": data[2],
            "experience": int(data[3]),
            "daily_status": data[4],
            "current_status": data[5]
        })

    return doctors

def read_appointments():
    appointments = []
    appointment_file = os.path.join(BACKEND_DIR, "data", "appointment.txt")
    try:
        with open(appointment_file, "r") as f:
            for line in f:
                data = line.strip().split("|")
                if len(data) < 6:
                    continue
                appointments.append({
                    "appointment_id": int(data[0]),
                    "patient_id": int(data[1]),
                    "doctor_id": int(data[2]),
                    "date": data[3],
                    "time_slot": data[4],
                    "status": data[5]
                })
    except:
        pass
    return appointments

def read_bills():
    bills = []
    bill_file = os.path.join(BACKEND_DIR, "data", "billing.txt")
    try:
        with open(bill_file, "r") as f:
            for line in f:
                data = line.strip().split("|")
                if len(data) < 13:
                    continue
                bills.append({
                    "bill_id": int(data[0]),
                    "date": data[1],
                    "patient_id": int(data[2]),
                    "name": data[3],
                    "doctor": data[6],
                    "department": data[7],
                    "total": data[11],
                    "status": data[12]
                })
    except:
        pass
    return bills

def read_patients():
    patients = []
    patient_file = os.path.join(BACKEND_DIR, "data", "patients.txt")
    try:
        with open(patient_file, "r") as f:
            for line in f:
                data = line.strip().split("|")
                if len(data) < 10:
                    continue
                patients.append({
                    "id": int(data[0]),
                    "name": data[1],
                    "age": data[2],
                    "gender": data[3],
                    "phone": data[4],
                    "address": data[5],
                    "symptoms": data[6],
                    "visit_type": data[7],
                    "priority": data[8],
                    "department": data[9]
                })
    except:
        pass
    return patients

def find_patient_by_phone(phone):
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "patient.exe")
    result = subprocess.run(
        [exe_path, "search", phone],
        capture_output=True,
        text=True
    )

    data = result.stdout.strip().split("|")
    if len(data) >= 11 and data[0] == "PATIENT":
        return {
            "id": int(data[1]),
            "name": data[2],
            "age": data[3],
            "gender": data[4],
            "phone": data[5],
            "address": data[6],
            "symptoms": data[7],
            "visit_type": data[8],
            "priority": data[9],
            "department": data[10]
        }

    return None

def find_patient_by_id(patient_id):
    for patient in read_patients():
        if patient["id"] == int(patient_id):
            return patient
    return None

def read_assigned_queue_patients(doctor_id):
    assigned = []
    patients = {patient["id"]: patient for patient in read_patients()}

    for item in read_queue():
        if item["doctor_id"] != doctor_id or item["status"] != "Waiting":
            continue

        patient = patients.get(item["patient_id"], {})
        assigned.append({
            "token": item["token"],
            "patient_id": item["patient_id"],
            "priority": item["priority"],
            "status": item["status"],
            "name": patient.get("name", ""),
            "department": patient.get("department", ""),
            "symptoms": patient.get("symptoms", "")
        })

    return assigned

def get_diagnosis_context(patient_id):
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "diagnosis.exe")
    result = subprocess.run(
        [exe_path, "history", str(patient_id)],
        capture_output=True,
        text=True
    )

    output = result.stdout.strip().split("\n")
    patient = None
    diagnosis = []
    error_message = None

    for line in output:
        data = line.split("|")
        if data[0] == "PatientNotFound":
            error_message = "Patient ID not found."
        elif data[0] == "PATIENT":
            patient = {
                "id": data[1],
                "name": data[2],
                "age": data[3],
                "gender": data[4],
                "phone": data[5],
                "address": data[6],
                "symptoms": data[7],
                "visit_type": data[8],
                "priority": data[9],
                "department": data[10]
            }
        elif data[0] == "DIAGNOSIS":
            diagnosis.append({
                "record_id": data[1],
                "doctor_id": data[3],
                "date": data[4],
                "diagnosis": data[5],
                "prescription": data[6]
            })

    return patient, diagnosis, error_message

def auto_generate_bill(patient_id, doctor_id, bill_date):
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "billing.exe")
    result = subprocess.run(
        [exe_path, "auto", str(patient_id), str(doctor_id), bill_date],
        capture_output=True,
        text=True
    )

    data = result.stdout.strip().split("|")
    if len(data) >= 6 and data[0] == "AUTO_BILL":
        return {
            "bill_id": data[1],
            "patient_id": data[2],
            "doctor_id": data[3],
            "total": data[4],
            "status": data[5]
        }

    return None


@app.route("/")
def dashboard():
    role = session.get("role")
    if role == "Receptionist":
        return redirect("/receptionist")
    if role == "Doctor":
        return redirect("/doctor")
    return redirect("/login")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    error = None
    doctors = get_doctors()

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "")
        doctor_id = request.form.get("doctor_id", "")

        if not username or not password or role not in {"Receptionist", "Doctor"}:
            error = "Please fill all required fields."
        elif any(u["username"] == username for u in read_users()):
            error = "Username already exists."
        elif role == "Doctor" and not doctor_id:
            error = "Doctor profile is required for doctor role."
        else:
            create_user(username, password, role, doctor_id if role == "Doctor" else "0")
            return redirect("/login")

    return render_template("signup.html", error=error, doctors=doctors)

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = authenticate_user(username, password)

        if user:
            session["logged_in"] = True
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["doctor_id"] = user["doctor_id"]
            if user["role"] == "Receptionist":
                return redirect("/receptionist")
            if user["role"] == "Doctor":
                return redirect("/doctor")
            return redirect("/")

        error = "Invalid username or password."

    return render_template("login.html", error=error)

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect("/login")

@app.route("/receptionist")
@require_role("Receptionist")
def receptionist_dashboard():
    queue = read_queue()
    queue, next_patient, waiting_count, completed_count = process_queue(queue)
    appointments = read_appointments()
    booked_count = len([a for a in appointments if a["status"] == "Booked"])
    cancelled_count = len([a for a in appointments if a["status"] == "Cancelled"])

    return render_template(
        "receptionist_dashboard.html",
        waiting_count=waiting_count,
        completed_count=completed_count,
        booked_count=booked_count,
        cancelled_count=cancelled_count,
        next_patient=next_patient
    )

@app.route("/doctor")
@require_role("Doctor")
def doctor_dashboard():
    doctor_id = int(session.get("doctor_id", "0") or 0)
    billing_patient_id = request.args.get("billing_patient_id", "")
    billing_doctor_id = request.args.get("doctor_id", str(doctor_id))
    billing_bill_id = request.args.get("bill_id", "")
    appointments = [
        a for a in read_appointments()
        if a["doctor_id"] == doctor_id and a["status"] in {"Booked", "No-show"}
    ]
    appointments.sort(key=lambda x: (x["date"], x["time_slot"]))
    queue_patients = read_assigned_queue_patients(doctor_id)

    doctor_info = next((d for d in get_doctors() if d["id"] == doctor_id), None)
    return render_template(
        "doctor_dashboard.html",
        appointments=appointments,
        queue_patients=queue_patients,
        doctor_info=doctor_info,
        billing_patient_id=billing_patient_id,
        billing_doctor_id=billing_doctor_id,
        billing_bill_id=billing_bill_id
    )

#patient
@app.route("/patient_search", methods=["GET", "POST"])
@require_role("Receptionist")
def patient_search():
    patient = None
    message = None

    if request.method == "POST":
        phone = request.form.get("phone", "").strip()
        patient = find_patient_by_phone(phone)
        if not patient:
            message = "Patient not found. Please register a new patient."

    return render_template("patient_search.html", patient=patient, message=message)

@app.route("/patient")
@require_role("Receptionist")
def patient():
    return render_template("patient.html")


#queue
@app.route("/add_patient", methods=["POST"])
@require_role("Receptionist")
def add_patient():

    name = request.form["name"]
    age = request.form["age"]
    gender = request.form["gender"]
    phone = request.form["phone"]    
    address = request.form["address"]
    symptoms = request.form["symptoms"]
    visit_type = request.form["visit_type"]
    priority = request.form["priority"]
    department = request.form["department"]
    encounter_type = request.form.get("encounter_type", "Appointment")

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "patient.exe")

    data_string = f"{name}|{age}|{gender}|{phone}|{address}|{symptoms}|{visit_type}|{priority}|{department}"
    
    patient_output = subprocess.run(
        [exe_path, data_string],
        capture_output=True,
        text=True
    )
    patient_output = patient_output.stdout.strip()
    data = patient_output.split("|")
    id = data[0]
    view_type = data[1]
    priority = data[2]

    queue_assigned = False
    if encounter_type == "Walk-in" or visit_type == "Emergency":
        queue_exe_path = os.path.join(BACKEND_DIR, "c_modules", "queue.exe")
        subprocess.run(
            [queue_exe_path, id, department, priority],
            capture_output=True,
            text=True
        )
        queue_assigned = True

    return render_template(
        "add_patient.html",
        patient_id=id,
        visit_type=visit_type,
        department=department,
        priority=priority,
        queue_assigned=queue_assigned
    )

@app.route("/queue")
@require_role("Receptionist")
def queue_page():

    queue = read_queue()
    queue, next_patient, waiting_count, completed_count = process_queue(queue)

    return render_template("queue.html",queue=queue, next_patient=next_patient, waiting_count=waiting_count, completed_count=completed_count )

@app.route("/appointments")
@require_role("Receptionist")
def appointments_page():
    doctors = get_doctors()
    appointments = read_appointments()
    selected_doctor = request.args.get("doctor_id", "")
    selected_department = request.args.get("department", "")
    selected_date = request.args.get("date", date.today().isoformat())
    slots = []
    suggested_doctors = []

    department_doctors = [d for d in doctors if d["department"] == selected_department] if selected_department else []

    if not selected_doctor and department_doctors:
        selected_doctor = str(department_doctors[0]["id"])

    if selected_doctor and selected_date:
        exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
        result = subprocess.run(
            [exe_path, "slots", selected_doctor, selected_date],
            capture_output=True,
            text=True
        )
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            data = line.strip().split("|")
            if len(data) == 3 and data[0] == "SLOT":
                slots.append({"time": data[1], "state": data[2]})

    if selected_department:
        for doc in suggest_doctors_by_department(selected_department):
            if str(doc["id"]) == str(selected_doctor):
                continue
            exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
            result = subprocess.run(
                [exe_path, "slots", str(doc["id"]), selected_date],
                capture_output=True,
                text=True
            )
            available_count = 0
            for line in result.stdout.strip().split("\n"):
                parts = line.strip().split("|")
                if len(parts) == 3 and parts[0] == "SLOT" and parts[2] == "Available":
                    available_count += 1
            if available_count > 0:
                suggested_doctors.append({
                    "id": doc["id"],
                    "name": doc["name"],
                    "department": doc["department"],
                    "available_slots": available_count
                })

    return render_template(
        "appointments.html",
        doctors=doctors,
        slots=slots,
        selected_doctor=selected_doctor,
        selected_department=selected_department,
        selected_date=selected_date,
        appointments=appointments,
        suggested_doctors=suggested_doctors
    )

@app.route("/book_appointment", methods=["POST"])
@require_role("Receptionist")
def book_appointment():
    patient_id = request.form["patient_id"]
    doctor_id = request.form["doctor_id"]
    appointment_date = request.form["appointment_date"]
    time_slot = request.form["time_slot"]

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
    subprocess.run(
        [exe_path, "book", patient_id, doctor_id, appointment_date, time_slot],
        capture_output=True,
        text=True
    )

    return redirect(f"/appointments?doctor_id={doctor_id}&date={appointment_date}")

@app.route("/cancel_appointment", methods=["POST"])
@require_role("Receptionist")
def cancel_appointment():
    appointment_id = request.form["appointment_id"]
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
    subprocess.run([exe_path, "cancel", appointment_id], capture_output=True, text=True)
    return redirect("/appointments")

@app.route("/reschedule", methods=["POST"])
@require_role("Receptionist")
def reschedule():
    appointment_id = request.form["appointment_id"]
    new_date = request.form["new_date"]
    new_time = request.form["new_time"]
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
    subprocess.run(
        [exe_path, "reschedule", appointment_id, new_date, new_time],
        capture_output=True,
        text=True
    )
    return redirect("/appointments")

@app.route("/update_appointment", methods=["POST"])
@require_role("Receptionist", "Doctor")
def update_appointment():
    appointment_id = request.form["appointment_id"]
    action = request.form["action"]

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")

    if action == "reschedule":
        new_date = request.form["new_date"]
        new_time = request.form["new_time"]
        subprocess.run(
            [exe_path, "reschedule", appointment_id, new_date, new_time],
            capture_output=True,
            text=True
        )
    elif action == "cancel":
        subprocess.run([exe_path, "cancel", appointment_id], capture_output=True, text=True)
    elif action == "complete":
        subprocess.run([exe_path, "complete", appointment_id], capture_output=True, text=True)
    elif action == "noshow":
        subprocess.run([exe_path, "noshow", appointment_id], capture_output=True, text=True)
    elif action == "reassign":
        new_doctor_id = request.form["new_doctor_id"]
        new_date = request.form["new_date"]
        new_time = request.form["new_time"]
        patient_id = request.form["patient_id"]
        subprocess.run([exe_path, "cancel", appointment_id], capture_output=True, text=True)
        subprocess.run(
            [exe_path, "book", patient_id, new_doctor_id, new_date, new_time],
            capture_output=True,
            text=True
        )

    if session.get("role") == "Doctor":
        return redirect("/doctor")
    return redirect("/appointments")


# Serve next patient
@app.route("/serve", methods=["POST"])
@require_role("Receptionist")
def serve():

    serve_exe = os.path.join(BACKEND_DIR, "c_modules", "serve.exe")

    serve_output = subprocess.run(
        [serve_exe],
        capture_output=True,
        text=True
    )

    serve_output = serve_output.stdout.strip()

    return redirect("/queue")

@app.route("/doctors")
@require_role("Receptionist")
def doctors_page():

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")

    result = subprocess.run(
        [exe_path, "view"],
        capture_output=True,
        text=True
    )

    doctors = []

    for line in result.stdout.strip().split("\n"):
        if line:
            data = line.split("|")
            doctors.append({
                "id": int(data[0]),
                "name": data[1],
                "department": data[2],
                "experience": int(data[3]),
                "daily_status": data[4],
                "current_status": data[5]
            })

    return render_template("doctors.html", doctors=doctors)


@app.route("/add_doctor", methods=["POST"])
@require_role("Receptionist")
def add_doctor():

    name = request.form["name"]
    department = request.form["department"]
    experience = request.form["experience"]

    data_string = f"{name}|{department}|{experience}"

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")

    result = subprocess.run(
        [exe_path, data_string],
        capture_output=True,
        text=True
    )

    print("STDOUT:", result.stdout)
    print("STDERR:", result.stderr)

    return redirect("/doctors")


@app.route("/toggle_doctor", methods=["POST"])
@require_role("Receptionist")
def toggle_doctor():

    doctor_id = request.form["doctor_id"]
    status = request.form["status"]

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")

    subprocess.run([exe_path, "daily", doctor_id, status])

    return redirect("/doctors")

@app.route("/doctor_status", methods=["POST"])
@require_role("Receptionist")
def doctor_status():
    doctor_id = request.form["doctor_id"]
    daily_status = request.form["daily_status"]
    current_status = request.form["current_status"]

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")
    subprocess.run([exe_path, "status", doctor_id, daily_status, current_status])
    return redirect("/doctors")

@app.route("/doctor_my_status", methods=["POST"])
@require_role("Doctor")
def doctor_my_status():
    doctor_id = session.get("doctor_id", "0")
    daily_status = request.form["daily_status"]
    current_status = request.form["current_status"]
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "doctor.exe")
    subprocess.run([exe_path, "status", doctor_id, daily_status, current_status])
    return redirect("/doctor")

@app.route("/doctor_complete_consultation", methods=["POST"])
@require_role("Doctor")
def doctor_complete_consultation():
    appointment_id = request.form["appointment_id"]
    patient_id = request.form["patient_id"]
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "appointment.exe")
    subprocess.run([exe_path, "complete", appointment_id], capture_output=True, text=True)
    return redirect(f"/diagnosis?patient_id={patient_id}")
@app.route("/diagnosis")
@require_role("Doctor")
def diagnosis_page():
    patient_id = request.args.get("patient_id", "").strip()
    if patient_id:
        patient, diagnosis, error_message = get_diagnosis_context(patient_id)
        return render_template(
            "diagnosis.html",
            patient=patient,
            diagnosis=diagnosis,
            error_message=error_message,
            current_doctor_id=session.get("doctor_id", ""),
            today=date.today().isoformat()
        )
    return render_template(
        "diagnosis.html",
        current_doctor_id=session.get("doctor_id", ""),
        today=date.today().isoformat()
    )


@app.route("/diagnosis_history", methods=["POST"])
@require_role("Doctor")
def diagnosis_history():

    patient_id = request.form["patient_id"]
    patient, diagnosis, error_message = get_diagnosis_context(patient_id)

    return render_template(
        "diagnosis.html",
        patient=patient,
        diagnosis=diagnosis,
        error_message=error_message,
        current_doctor_id=session.get("doctor_id", ""),
        today=date.today().isoformat()
    )


@app.route("/add_diagnosis", methods=["POST"])
@require_role("Doctor")
def add_diagnosis():

    patient_id = request.form["patient_id"]
    doctor_id = session.get("doctor_id", request.form.get("doctor_id", "0"))
    date = request.form["date"]
    diagnosis_text = request.form["diagnosis"]
    prescription = request.form["prescription"]

    data_string = f"{patient_id}|{doctor_id}|{date}|{diagnosis_text}|{prescription}"

    exe_path = os.path.join(BACKEND_DIR, "c_modules", "diagnosis.exe")

    subprocess.run(
        [exe_path, data_string],
        capture_output=True,
        text=True
    )

    bill = auto_generate_bill(patient_id, doctor_id, date)
    if bill:
        return redirect(
            f"/doctor?billing_patient_id={patient_id}&doctor_id={doctor_id}&bill_id={bill['bill_id']}"
        )

    return redirect(f"/doctor?billing_patient_id={patient_id}&doctor_id={doctor_id}")

@app.route("/billing")
@require_role("Receptionist")
def billing_page():
    bills = read_bills()
    patient_id = request.args.get("patient_id", "")
    doctor_id = request.args.get("doctor_id", "")
    prefill = {}
    patient = find_patient_by_id(patient_id) if patient_id else None
    doctor = next((d for d in get_doctors() if str(d["id"]) == str(doctor_id)), None) if doctor_id else None

    if patient:
        prefill["patient_id"] = patient["id"]
        prefill["patient_name"] = patient["name"]
        prefill["age"] = patient["age"]
        prefill["gender"] = patient["gender"]
        prefill["department"] = patient["department"]
        prefill["date"] = date.today().isoformat()
    if doctor:
        prefill["doctor"] = f"Dr. {doctor['name']}"

    return render_template("billing.html", bills=bills, bill_preview="", prefill=prefill)

@app.route("/generate_bill", methods=["POST"])
@require_role("Receptionist")
def generate_bill():
    patient_id = request.form["patient_id"]
    patient_name = request.form["patient_name"]
    age = request.form["age"]
    gender = request.form["gender"]
    doctor = request.form["doctor"]
    department = request.form["department"]
    bill_date = request.form["date"]
    consultation = request.form["consultation"]
    medicines = request.form["medicines"]
    lab_tests = request.form["lab_tests"]
    payment_status = request.form["payment_status"]

    data_string = f"{patient_id}|{patient_name}|{age}|{gender}|{doctor}|{department}|{bill_date}|{consultation}|{medicines}|{lab_tests}|{payment_status}"
    exe_path = os.path.join(BACKEND_DIR, "c_modules", "billing.exe")

    result = subprocess.run(
        [exe_path, data_string],
        capture_output=True,
        text=True
    )

    bills = read_bills()
    return render_template("billing.html", bills=bills, bill_preview=result.stdout, prefill={})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
